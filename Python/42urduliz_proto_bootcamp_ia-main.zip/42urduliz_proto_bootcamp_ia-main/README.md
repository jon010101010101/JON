# 42urduliz_proto_bootcamp_ia
Ejercicios y tareas para conocer e aprender el uso de python y IA.
