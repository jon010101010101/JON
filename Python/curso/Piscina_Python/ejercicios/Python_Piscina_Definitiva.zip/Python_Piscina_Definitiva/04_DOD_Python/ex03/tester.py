from new_student import Student
student = Student(name = "Edmund", surname = "agle")
print(student)
