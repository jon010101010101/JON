from statistics import ft_statistics

ft_statistics(42, 115, 30, 151, 6400, toto="mean", tutu="std", tata="quartile", titi="djdj")
print("-----")
ft_statistics(51, 735, 455, 8, 7, 74, 75, hello="median", world="var")
print("-----")
ft_statistics(5, 75, 450, 18, 597, 27474, 48575, ejfhhe='fdff', ejdjdejn="demiane")
print("-----")
ft_statistics(hello="std", world="median")
