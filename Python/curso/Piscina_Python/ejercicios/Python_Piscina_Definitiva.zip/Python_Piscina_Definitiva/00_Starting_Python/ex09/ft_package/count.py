def count_in_list(lst, item):
    """Counts how many times an item appears in the list."""
    return lst.count(item)
