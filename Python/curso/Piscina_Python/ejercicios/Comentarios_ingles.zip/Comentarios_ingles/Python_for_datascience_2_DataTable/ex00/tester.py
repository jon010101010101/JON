from load_csv import load
print(load("life_expectancy_years.csv"))