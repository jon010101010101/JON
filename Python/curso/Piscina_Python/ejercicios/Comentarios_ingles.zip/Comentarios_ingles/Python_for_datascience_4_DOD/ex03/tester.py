#from new_student import Student
#student = Student(name = "Edward", surname = "agle")
#print(student)

from new_student import Student
student = Student(name = "Edward", surname = "agle", id = "toto")
print(student)