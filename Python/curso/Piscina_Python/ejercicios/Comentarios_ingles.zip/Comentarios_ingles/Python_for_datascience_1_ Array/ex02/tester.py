from load_image import ft_load
print(ft_load("landscape.npg"))