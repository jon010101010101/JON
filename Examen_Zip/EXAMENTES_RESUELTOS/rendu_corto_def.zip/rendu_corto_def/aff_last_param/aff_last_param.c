/*Assignment name  : aff_last_param
Expected files   : aff_last_param.c
Allowed functions: write
--------------------------------------------------------------------------------
Write a program that takes strings as arguments, and displays its last
argument followed by a newline.
If the number of arguments is less than 1, the program displays a newline.
--------------------------------------------------------------------------------
Escribe un programa que tome cadenas como argumentos y muestre su último
argumento seguido de una nueva línea.
Si el número de argumentos es menor que 1, el programa muestra una nueva línea.

Examples:
$> ./aff_last_param "zaz" "mange" "des" "chats" | cat -e
chats$
$> ./aff_last_param "j'aime le savon" | cat -e
j'aime le savon$
$> ./aff_last_param | cat -e
$*/

/* FUNCIONA Y PASA MAQUINA */

#include <unistd.h>

int main(int argc, char **argv)
{
    int  i = 0;

    if (argc >1)
    {
        while (argv[argc-1][i] != '\0')
            write(1, &argv[argc - 1][i++], 1); 
    }
    write(1, "\n", 1);
    return (0);
}